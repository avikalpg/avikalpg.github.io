
** READ ME FOR INSTRUCTIONS TO RUN THIS SCRIPT ON ANY CORPUS <corpus.txt> **

1. The name of the main file is hw1_try01.py
2. The script devanagri_terminals.py is the helper script for terminals of the devanagri script. If you want to run Choudhary's algorithm on any other script, you can write a python file similar to this script.
3. To run the syllable counter, type the following on the terminal and press enter:
        > python hw1_try01.py devanagri_terminals.py <corpus.txt>
